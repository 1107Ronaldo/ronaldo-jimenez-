import tkinter as tk
import json
from tkinter import messagebox, ttk
import util.generic as utl
class PAdmin(tk.Tk):
    def __init__(self, name="", username="", email=""):
        self.name = name
        self.username = username
        self.email = email
        super().__init__()
        self.title("Panel Administrativo")
        self.resizable(False, False)
        # Obtener las dimensiones de la pantalla
        self.ancho_pantalla = self.winfo_screenwidth() #método para obtener Ancho
        self.alto_pantalla = self.winfo_screenheight() #método para obtener Alto

        # Establecer el tamaño completo de la ventana
        self.geometry(f"{self.ancho_pantalla}x{self.alto_pantalla}")
        
        menubar = tk.Menu(self)  
        menuuser = tk.Menu(menubar, tearoff=0)  
        menuuser.add_command(label="Crear Usuario", command=self.crear_usuario_form)  
        menuuser.add_command(label="Listar Usuarios", command=self.listar_usuarios) 
        menubar.add_cascade(label="Usuarios", menu=menuuser)  

        menuclientes = tk.Menu(menubar, tearoff=0)
        menuclientes.add_command(label="Crear Cliente", command=self.crear_cliente_form)  
        menuclientes.add_command(label="Listar Clientes", command=self.listar_clientes)  
        menubar.add_cascade(label="Clientes", menu=menuclientes)

        menuventas = tk.Menu(menubar, tearoff=0)
        menuventas.add_command(label="Crear Corte", command=self.crear_cortes_form)  
        menuventas.add_command(label="Listar Cortes", command=self.listar_cortes)  
        menubar.add_cascade(label="Cortes", menu=menuventas)

        menucategorias = tk.Menu(menubar, tearoff=0)
        menucategorias.add_command(label="Crear Reserva", command=self.crear_reserva_form)  
        menucategorias.add_command(label="Listar Reservas", command=self.listar_reserva)  
        menubar.add_cascade(label="Reservas", menu=menucategorias)   

        menuproducto = tk.Menu(menubar, tearoff=0)
        menuproducto.add_command(label="Crear Producto",command= self.crear_venta_form)
        menuproducto.add_command(label="Listar Productos",command= self.listar_venta)  
        menubar.add_cascade(label="Ventas", menu=menuproducto)   

        self.config(menu=menubar)

        # frame user info

        self.frame_user_info = tk.Frame(self, bd=0,relief=tk.SOLID, width=200)
        self.frame_user_info.pack(side=tk.LEFT, padx=4, pady=5,fill="y")
        texto=tk.Label(self.frame_user_info, text="PANEL ADMINISTRATIVO", font=('Times', 25))
        texto.pack(padx=20,pady=4)
        self.usrimg = utl.leer_imagen(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\imagenes\userinfo.png", (100, 100))
        self.imgusr=tk.Label(self.frame_user_info,image=self.usrimg)
        self.imgusr.pack(padx=30,pady=4)
        texto1=tk.Label(self.frame_user_info, text=self.name, font=('Times', 20))
        texto1.pack(padx=40,pady=4)
        texto1=tk.Label(self.frame_user_info, text=self.email, font=('Times', 20))
        texto1.pack(padx=50,pady=4)
        
        #frame_data
        
        self.frame_data = tk.Frame(self, bd=0,relief=tk.SOLID, width=f"{self.ancho_pantalla-200}")
        self.frame_data.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)
        textobienvenida=tk.Label(self.frame_data, text="BIENVENIDO AL SISTEMA", font=('Times', 20))
        textobienvenida.pack(padx=20,pady=4)

        #frame_dinamyc
        self.frame_dinamyc = tk.Frame(self.frame_data, bd=0,relief=tk.SOLID, width=f"{self.ancho_pantalla-200}")
        self.frame_dinamyc.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)
        #textobienvenida=tk.Label(self.frame_dinamyc, text="DINAMICO", font=('Times', 20))
        #textobienvenida.pack(padx=20,pady=4)

    def crear_usuario_form(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="REGISTRO DE USUARIOS", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        
        labelcedula = tk.Label(self.frame_dinamyc,text="Cedula:", font=('Times',14))
        labelcedula.place(x=70, y=100)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=80)
        self.ccedula.place(x=220, y=100)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=130)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=80)
        self.cnombre.place(x=220, y=130)

        labelusuario = tk.Label(self.frame_dinamyc,text="Username:", font=('Times',14))
        labelusuario.place(x=70,y=160)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=80)
        self.cusuario.place(x=220,y=160)

        labelclave = tk.Label(self.frame_dinamyc,text="Contraseña:", font=('Times',14))
        labelclave.place(x=70,y=190)
        self.cclave = tk.Entry(self.frame_dinamyc, width=80, show="*")
        self.cclave.place(x=220, y=190)

        labelcorreo = tk.Label(self.frame_dinamyc,text="Correo:", font=('Times',14))
        labelcorreo.place(x=70,y=220)
        self.ccorreo = tk.Entry(self.frame_dinamyc, width=80)
        self.ccorreo.place(x=220, y=220)

        labeltipo = tk.Label(self.frame_dinamyc, text="Tipo:")
        labeltipo.place(x=70,y=250)
        self.listatipo = tk.Listbox(self.frame_dinamyc, selectmode="Single", width=80, height=2)
        self.listatipo.place(x=220,y=250)
        self.listatipo.insert(1, "Administrador")
        self.listatipo.insert(2, "Vendedor")

        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times',14), command=self.save_user)
        btnguardar.place(x=220, y=300)
    
    def listar_usuarios(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="\uf00b LISTADO DE USUARIOS", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("NombreCompleto", "Username", "Email", "Rol"))
        self.tablausuarios.heading("#0", text="Cedula")
        self.tablausuarios.heading("NombreCompleto", text="Nombre Completo")
        self.tablausuarios.heading("Username", text="Usuario")
        self.tablausuarios.heading("Email", text="Email")
        self.tablausuarios.heading("Rol", text="Rol")
        with open("\\Users\\Administrator\\Desktop\\parcial final\\LoginApp\\formularios\\data\\db_users.json", "r", encoding='utf-8') as file:
                db_users = json.load(file)
                for usuarios in db_users["users"]:
                    self.tablausuarios.insert("", "end", text=f'{usuarios["id"]}',values=(f'{usuarios["name"]}',f'{usuarios["username"]}',f'{usuarios["email"]}', f'{usuarios["role"]}'))
        self.tablausuarios.place(x=70, y=100)

        labelcoordenada = tk.Label(self.frame_dinamyc,text="Coordenada del usuario:", font=('Times',14))
        labelcoordenada.place(x=70,y=350)
        coordenada = tk.Entry(self.frame_dinamyc,font=('Times',14))
        coordenada.place(x= 280,y=350)

        labelcedula = tk.Label(self.frame_dinamyc,text="Cedula:", font=('Times',14))
        labelcedula.place(x=70, y= 380)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=80)
        self.ccedula.place(x=280, y=380)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=410)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=80)
        self.cnombre.place(x=280, y=410)

        labelusuario = tk.Label(self.frame_dinamyc,text="Username:", font=('Times',14))
        labelusuario.place(x=70,y= 440)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=80)
        self.cusuario.place(x=280,y=440)

        labelclave = tk.Label(self.frame_dinamyc,text="Contraseña:", font=('Times',14))
        labelclave.place(x=70,y=470)
        self.cclave = tk.Entry(self.frame_dinamyc, width=80, show="*")
        self.cclave.place(x=280, y=470)

        labelcorreo = tk.Label(self.frame_dinamyc,text="Correo:", font=('Times',14))
        labelcorreo.place(x=70,y=500)
        self.ccorreo = tk.Entry(self.frame_dinamyc, width=80)
        self.ccorreo.place(x=280, y=500)

        labeltipo = tk.Label(self.frame_dinamyc, text="Tipo:",font=('Times',14))
        labeltipo.place(x=70,y=530)
        self.listatipo = tk.Listbox(self.frame_dinamyc, selectmode="Single", width=80, height=2)
        self.listatipo.place(x=280,y=530)
        self.listatipo.insert(1, "Administrador")
        self.listatipo.insert(2, "Vendedor")

        def eliminar():

            if  coordenada.get() == "" :
                
                messagebox.showerror("","rellene los campos")
            else:

                nuevo = db_users["users"]

                coordenadaa = int(coordenada.get())
                del nuevo[coordenadaa]

                with open("\\Users\\Administrator\\Desktop\\parcial final\\LoginApp\\formularios\\data\\db_users.json", 'w') as jf: 
                        json.dump(db_users, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Usuario eliminado con exito",parent=self)

        def actualizar():

            for index in self.listatipo.curselection():
                tipo_user = self.listatipo.get(index) 

            coordenadaa = int(coordenada.get())
            nuevo = db_users["users"]

            if  coordenada.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:

                for cl in nuevo:

                    Id = self.ccedula.get() or cl["id"]
                    nombre = self.cnombre.get() or cl["name"]
                    usuario = self.cusuario.get() or cl["username"]
                    clave = self.cclave.get() or cl["password"]
                    correo = self.ccorreo.get() or cl["email"]
                    rol = tipo_user or cl["role"]

                nuevo[coordenadaa] = {
                    "id": Id,
                    "name": nombre,
                    "username": usuario,
                    "password": clave,
                    "email": correo,
                    "role" : rol
                }


                with open("\\Users\\Administrator\\Desktop\\parcial final\\LoginApp\\formularios\\data\\db_users.json", 'w') as jf: 
                        json.dump(db_users, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Usuario actualizado con exito",parent=self)

    
        btnelimina = tk.Button(self.frame_dinamyc, text="ELIMINAR", font=('Times',14),command= eliminar)
        btnelimina.place(x=70, y=600)
 
        btnactualizar = tk.Button(self.frame_dinamyc, text="ACTUALIZAR", font=('Times',14),command=actualizar)
        btnactualizar.place(x= 280, y=600)


    def save_user(self):
        for index in self.listatipo.curselection():
            tipo_user = self.listatipo.get(index)
            
        with open("\\Users\\Administrator\\Desktop\\parcial final\\LoginApp\\formularios\\data\\db_users.json", "r", encoding='utf-8') as file:
                db_users = json.load(file)
                db_users["users"].append({
                        'id': self.ccedula.get(),
                        'name': self.cnombre.get(),
                        'username': self.cusuario.get(),
                        'password': self.cclave.get(),
                        'email': self.ccorreo.get(),
                        'role':tipo_user
                    })
                with open("\\Users\\Administrator\\Desktop\\parcial final\\LoginApp\\formularios\\data\\db_users.json", 'w') as jf: 
                    json.dump(db_users, jf, indent=4, ensure_ascii=True)
                    messagebox.showinfo('Info',"Usuario registrado con exito",parent=self)


##clientes


    def crear_cliente_form(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="REGISTRO DE CLIENTES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        
        labelcedula = tk.Label(self.frame_dinamyc,text="Cedula:", font=('Times',14))
        labelcedula.place(x=70, y=100)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=80)
        self.ccedula.place(x=220, y=100)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=130)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=80)
        self.cnombre.place(x=220, y=130)

        labelusuario = tk.Label(self.frame_dinamyc,text="Username:", font=('Times',14))
        labelusuario.place(x=70,y=160)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=80)
        self.cusuario.place(x=220,y=160)

        labelclave = tk.Label(self.frame_dinamyc,text="Contraseña:", font=('Times',14))
        labelclave.place(x=70,y=190)
        self.cclave = tk.Entry(self.frame_dinamyc, width=80, show="*")
        self.cclave.place(x=220, y=190)

        labeltelefono = tk.Label(self.frame_dinamyc,text="telefono:", font=('Times',14))
        labeltelefono.place(x=70,y=220)
        self.telefono = tk.Entry(self.frame_dinamyc, width=80)
        self.telefono.place(x=220, y=220)


        btnguardar = tk.Button(self.frame_dinamyc, text="GUARDAR", font=('Times',14), command=self.save_cliente)
        btnguardar.place(x=220, y=300)
    
    def listar_clientes(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="LISTADO DE CLIENTES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("NombreCompleto", "Username", "celular"))
        self.tablausuarios.heading("#0", text="Cedula")
        self.tablausuarios.heading("NombreCompleto", text="Nombre Completo")
        self.tablausuarios.heading("Username", text="Usuario")
        self.tablausuarios.heading("celular", text="celular")

        with open(r"\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json", "r", encoding='utf-8') as file:
                clientes = json.load(file)
                for usuarios in clientes["clientes"]:
                    self.tablausuarios.insert("", "end", text=f'{usuarios["id"]}',values=(f'{usuarios["name"]}',f'{usuarios["username"]}',f'{usuarios["telefono"]}'))
        self.tablausuarios.place(x=70, y=100)

        labelcoordenada = tk.Label(self.frame_dinamyc,text="Coordenada del cliente:", font=('Times',14))
        labelcoordenada.place(x=70,y=350)
        coordenada = tk.Entry(self.frame_dinamyc,font=('Times',14))
        coordenada.place(x= 280,y=350)

        labelcedula = tk.Label(self.frame_dinamyc,text="Cedula:", font=('Times',14))
        labelcedula.place(x=70, y= 380)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=80)
        self.ccedula.place(x=280, y=380)

        labelnombre = tk.Label(self.frame_dinamyc,text="Nombre completo:", font=('Times',14))
        labelnombre.place(x=70, y=410)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=80)
        self.cnombre.place(x=280, y=410)

        labelusuario = tk.Label(self.frame_dinamyc,text="usuario:", font=('Times',14))
        labelusuario.place(x=70,y= 440)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=80)
        self.cusuario.place(x=280,y=440)

        labelclave = tk.Label(self.frame_dinamyc,text="Contraseña:", font=('Times',14))
        labelclave.place(x=70,y=470)
        self.cclave = tk.Entry(self.frame_dinamyc, width=80, show="*")
        self.cclave.place(x=280, y=470)

        labeltelefono = tk.Label(self.frame_dinamyc,text="telefono:", font=('Times',14))
        labeltelefono.place(x=70,y=500)
        self.telefono = tk.Entry(self.frame_dinamyc, width=80)
        self.telefono.place(x=280, y=500)

        def eliminar():

            if  coordenada.get() == "" :
                
                messagebox.showerror("","rellene los campos")
            else:

                nuevo = clientes["clientes"]

                coordenadaa = int(coordenada.get())
                del nuevo[coordenadaa]

                with open(r"\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json", 'w') as jf: 
                        json.dump(clientes, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Cliente eliminado con exito",parent=self)

        def actualizar():

            if  self.ccedula.get() == "" or self.cnombre.get() == "" or self.cusuario.get() == "" or self.cclave.get() == "" or self.telefono.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:

                coordenadaa = int(coordenada.get())
                nuevo = clientes["clientes"]

                for cl in nuevo:

                    Id = self.ccedula.get() or cl["id"]
                    nombre = self.cnombre.get() or cl["name"]
                    usuario = self.cusuario.get() or cl["username"]
                    clave = self.cclave.get() or cl["password"]
                    telefono = self.telefono.get() or cl["telefono"]

                nuevo[coordenadaa] = {
                    "id": Id,
                    "name": nombre,
                    "username": usuario,
                    "password": clave,
                    "telefono": telefono
                    
                }


            with open(r"\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json", 'w') as jf: 
                    json.dump(clientes, jf, indent=4, ensure_ascii=True)
                    messagebox.showinfo('Info',"Cliente actualizado con exito",parent=self)

    
        btnelimina = tk.Button(self.frame_dinamyc, text="ELIMINAR", font=('Times',14),command= eliminar)
        btnelimina.place(x=70, y=550)
 
        btnactualizar = tk.Button(self.frame_dinamyc, text="ACTUALIZAR", font=('Times',14),command=actualizar)
        btnactualizar.place(x= 280, y=550)


    def save_cliente(self):

            if  self.ccedula.get() == "" or self.cnombre.get() == "" or self.cusuario.get() == "" or self.cclave.get() == "" or self.telefono.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:
            
                with open(r"\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json", "r", encoding='utf-8') as file:
                        clientes = json.load(file)
                        clientes["clientes"].append({
                                'id': self.ccedula.get(),
                                'name': self.cnombre.get(),
                                'username': self.cusuario.get(),
                                'password': self.cclave.get(),
                                'telefono': self.telefono.get()
                            })
                        with open(r"\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json", 'w') as jf: 
                            json.dump(clientes, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Cliente registrado con exito",parent=self)

##cortes

    def crear_cortes_form(self):
            self.limpiar_panel(self.frame_dinamyc)
            labelform = tk.Label(self.frame_dinamyc,text="REGISTRO DE CORTES Y SERVICIOS", font=('Times',16),fg="#9fa8da")
            labelform.place(x=70, y=70)
            
            labelcorte = tk.Label(self.frame_dinamyc,text="Corte o Servicio: ", font=('Times',14))
            labelcorte.place(x=70, y=130)
            self.corte = tk.Entry(self.frame_dinamyc, width=80)
            self.corte.place(x=220, y=130)

            labelprecio = tk.Label(self.frame_dinamyc,text="Precio: ", font=('Times',14))
            labelprecio.place(x=70, y=160)
            self.precio = tk.Entry(self.frame_dinamyc, width=80)
            self.precio.place(x=220, y=160)

        

            btnguardar = tk.Button(self.frame_dinamyc, text="GUARDAR", font=('Times',14), command=self.save_corte)
            btnguardar.place(x=220, y= 230)
        
    def listar_cortes(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="LISTADO DE CORTES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("Precio"))
        self.tablausuarios.heading("#0", text="Corte o Servicio")
        self.tablausuarios.heading("Precio", text="Precio")

        with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", "r", encoding='utf-8') as file:
                cortes = json.load(file)
                for usuarios in cortes["cortes"]:
                    self.tablausuarios.insert("", "end", text=f'{usuarios["Corte o Servicio"]}',values=(f'{usuarios["precio"]}'))
        self.tablausuarios.place(x=70, y=100)

        labelcoordenada = tk.Label(self.frame_dinamyc,text="Coordenada del corte:", font=('Times',14))
        labelcoordenada.place(x=70,y=350)
        coordenada = tk.Entry(self.frame_dinamyc,font=('Times',14))
        coordenada.place(x= 280,y=350)

        labelcorte = tk.Label(self.frame_dinamyc,text="Corte o servicio:", font=('Times',14))
        labelcorte.place(x=70, y= 380)
        self.corte = tk.Entry(self.frame_dinamyc, width=80)
        self.corte.place(x=280, y=380)

        labelprecio = tk.Label(self.frame_dinamyc,text="precio :", font=('Times',14))
        labelprecio.place(x=70, y=410)
        self.precio = tk.Entry(self.frame_dinamyc, width=80)
        self.precio.place(x=280, y=410)


        def eliminar():

            if coordenada.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:

                nuevo = cortes["cortes"]

                coordenadaa = int(coordenada.get())
                del nuevo[coordenadaa]

                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", 'w') as jf: 
                        json.dump(cortes, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Corte eliminado con exito",parent=self)

        def actualizar():

            if self.corte.get() == "" or self.precio.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:

                coordenadaa = int(coordenada.get())
                nuevo = cortes["cortes"]

                for cl in nuevo:

                    nombre = self.corte.get() or cl["Corte o Servicio"]
                    precio = int(self.precio.get()) or cl["precio"]
                    

                nuevo[coordenadaa] = {
                    "Corte o Servicio": nombre,
                    "precio": int(precio)
                }


                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", 'w') as jf: 
                        json.dump(cortes, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Actualizacion exitosa",parent=self)

    
        btneliminar = tk.Button(self.frame_dinamyc, text="ELIMINAR", font=('Times',14),command= eliminar)
        btneliminar.place(x=70, y=500)

        btnactualiza = tk.Button(self.frame_dinamyc, text="ACTUALIZAR", font=('Times',14),command=actualizar)
        btnactualiza.place(x= 280, y=500)


    def save_corte(self):
            
            if self.corte.get() == "" or self.precio.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:
                
                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", "r", encoding='utf-8') as file:
                        cortes = json.load(file)
                        cortes["cortes"].append({
                                'Corte o Servicio': self.corte.get(),
                                'precio': int(self.precio.get())
                            })
                        with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", 'w') as jf: 
                            json.dump(cortes, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Corte registrado con exito",parent=self)

##Reservas

    def cancha_selection(self, event):
        self.seleccion_cliente = self.combo_cliente.get()

    def cortes_selection(self, event):
        self.seleccion_corte = self.combo_corte.get()

    def crear_reserva_form(self):

        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="REGISTRO DE RESERVAS", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        
        labelcorte = tk.Label(self.frame_dinamyc,text="Cliente: ", font=('Times',14))
        labelcorte.place(x=70, y=130)


        with open(r'C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json', 'r') as jf:
            clientes = json.load(jf)
        
        clientess = [clien["name"] for clien in clientes["clientes"]]
        


        self.combo_cliente = ttk.Combobox(self.frame_dinamyc,
            values= clientess
        )
        self.combo_cliente.place(x= 220, y=130)
        self.combo_cliente.bind("<<ComboboxSelected>>", self.cancha_selection)



        labelprecio = tk.Label(self.frame_dinamyc,text="Corte: ", font=('Times',14))
        labelprecio.place(x=70, y=160)

        with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", 'r') as jf:
            cortes = json.load(jf)
        
        cortess = [clien["Corte o Servicio"] for clien in cortes["cortes"]]

        self.combo_corte = ttk.Combobox(self.frame_dinamyc,
            values= cortess
        )
        self.combo_corte.place(x= 220, y=160)
        self.combo_corte.bind("<<ComboboxSelected>>", self.cortes_selection)

        labelfecha = tk.Label(self.frame_dinamyc,text="Fecha: ", font=('Times',14))
        labelfecha.place(x=70, y=190)
        self.fecha = tk.Entry(self.frame_dinamyc, width=80)
        self.fecha.place(x=220, y=190)

        labelhora = tk.Label(self.frame_dinamyc,text="Hora: ", font=('Times',14))
        labelhora.place(x=70, y=220)
        self.hora = tk.Entry(self.frame_dinamyc, width=80)
        self.hora.place(x=220, y=220)

    
        btnguardar = tk.Button(self.frame_dinamyc, text="GUARDAR", font=('Times',14), command=self.save_reserva)
        btnguardar.place(x=220, y= 270)
            
    def listar_reserva(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc,text="LISTADO DE CORTES", font=('Times',16),fg="#9fa8da")
        labelform.place(x=70, y=70)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("corte","fecha","hora"))
        self.tablausuarios.heading("#0", text="cliente")
        self.tablausuarios.heading("corte", text="corte")
        self.tablausuarios.heading("fecha", text="fecha")
        self.tablausuarios.heading("hora", text="hora")

        with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reservas.json", "r", encoding='utf-8') as file:
                reservas = json.load(file)
                for usuarios in reservas["reservas"]:
                    self.tablausuarios.insert("", "end", text=f'{usuarios["cliente"]}',values=(f'{usuarios["corte"]}',f'{usuarios["fecha"]}',f'{usuarios["hora"]}'))
        self.tablausuarios.place(x=70, y=100)

        labelcoordenada = tk.Label(self.frame_dinamyc,text="Coordenada de la reserva:", font=('Times',14))
        labelcoordenada.place(x=70,y=350)
        coordenada = tk.Entry(self.frame_dinamyc,font=('Times',14))
        coordenada.place(x= 280,y=350)

        labelcorte = tk.Label(self.frame_dinamyc,text="Cliente: ", font=('Times',14))
        labelcorte.place(x=70, y=380)

        with open(r'C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\clientes.json', 'r') as jf:
            clientes = json.load(jf)
        
        clientess = [clien["name"] for clien in clientes["clientes"]]

        self.combo_cliente = ttk.Combobox(self.frame_dinamyc,
            values= clientess
        )
        self.combo_cliente.place(x= 220, y=380)
        self.combo_cliente.bind("<<ComboboxSelected>>", self.cancha_selection)

        labelprecio = tk.Label(self.frame_dinamyc,text="Corte: ", font=('Times',14))
        labelprecio.place(x=70, y=410)
        
        with open(r'C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json', 'r') as jf:
            cortes = json.load(jf)
        
        cortess = [clien["Corte o Servicio"] for clien in cortes["cortes"]]

        self.combo_corte = ttk.Combobox(self.frame_dinamyc,
            values= cortess
        )
        self.combo_corte.place(x= 220, y=410)
        self.combo_corte.bind("<<ComboboxSelected>>", self.cortes_selection)

        labelfecha = tk.Label(self.frame_dinamyc,text="Fecha: ", font=('Times',14))
        labelfecha.place(x=70, y=440)
        self.fecha = tk.Entry(self.frame_dinamyc, width=80)
        self.fecha.place(x=220, y=440)

        labelhora = tk.Label(self.frame_dinamyc,text="Hora: ", font=('Times',14))
        labelhora.place(x=70, y=470)
        self.hora = tk.Entry(self.frame_dinamyc, width=80)
        self.hora.place(x=220, y=470)


        def eliminar():

            if coordenada.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:

                nuevo = reservas["reservas"]

                coordenadaa = int(coordenada.get())
                del nuevo[coordenadaa]

                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reservas.json", 'w') as jf: 
                        json.dump(reservas, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Reserva eliminada con exito",parent=self)

        def actualizar():

            if self.fecha.get() == "" or self.hora.get() == "":
                
                messagebox.showerror("","rellene los campos")
            else:

                coordenadaa = int(coordenada.get())
                nuevo = reservas["reservas"]

                for cl in nuevo:

                    cliente = self.seleccion_cliente or cl["Cliente"]
                    corte = self.seleccion_corte or cl["corte"]
                    fecha = self.fecha.get() or cl["fecha"]
                    hora = self.hora.get() or cl["hora"]
                    

                nuevo[coordenadaa] = {
                    "cliente": cliente,
                    "corte": corte,
                    "fecha": fecha,
                    "hora": hora
                }


                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reservas.json", 'w') as jf: 
                        json.dump(reservas, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"Actualizacion exitosa",parent=self)

    
        btneliminar = tk.Button(self.frame_dinamyc, text="ELIMINAR", font=('Times',14),command= eliminar)
        btneliminar.place(x=70, y=530)

        btnactualiza = tk.Button(self.frame_dinamyc, text="ACTUALIZAR", font=('Times',14),command=actualizar)
        btnactualiza.place(x= 280, y=530)


    def save_reserva(self):
                
        if self.fecha.get() == "" or self.hora.get() == "":
            
            messagebox.showerror("","rellene los campos")
        else:
            
            with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reserva.json", "r", encoding='utf-8') as file:
                    reservas = json.load(file)
                    reservas["reservas"].append({
                            'cliente': self.seleccion_cliente,
                            'corte': self.seleccion_corte,
                            'fecha': self.fecha.get(),
                            'hora': self.hora.get()
                        })
                    with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reserva.json", 'w') as jf: 
                        json.dump(reservas, jf, indent=4, ensure_ascii=True)
                        messagebox.showinfo('Info',"reserva registrada con exito",parent=self)

    
## ventas

    def cliente_selection(self, event):

            self.seleccion_cliente = self.combo_cliente.get()
        

    def pago_selection(self, event):
            self.seleccion_pago = self.combo_pago.get()


    def crear_venta_form(self):
            


            self.limpiar_panel(self.frame_dinamyc)
            labelform = tk.Label(self.frame_dinamyc,text="REGISTRO DE VENTAS", font=('Times',16),fg="#9fa8da")
            labelform.place(x=70, y=70)
            
            labelreservas = tk.Label(self.frame_dinamyc,text="Reservas: ", font=('Times',14))
            labelreservas.place(x=70, y=130)

            with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\cortes.json", 'r') as jf:
                totall = json.load(jf)
            
            with open(r'C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reserva.json', 'r') as jf:
                reservaaa = json.load(jf)
            
            clies = [clien["cliente"] for clien in reservaaa["reservas"]]
            
            global total
            total = [clien["precio"] for clien in totall["cortes"]]
            print(total)

            self.combo_cliente = ttk.Combobox(self.frame_dinamyc,
                values= clies
            )
            self.combo_cliente.place(x= 220, y=130)
            self.combo_cliente.bind("<<ComboboxSelected>>", self.cliente_selection)
            
            hhhh = self.combo_cliente.current()
            global co
            co = total[hhhh]

            labelprecio = tk.Label(self.frame_dinamyc,text="PAGO: ", font=('Times',14))
            labelprecio.place(x=70, y=160)

            self.combo_pago = ttk.Combobox(self.frame_dinamyc,
                values= ["Transferencia","En la barberia"]
            )
            self.combo_pago.place(x= 220, y=160)
            self.combo_pago.bind("<<ComboboxSelected>>", self.pago_selection)


        
            btnguardar = tk.Button(self.frame_dinamyc, text="CONFIRMAR VENTA", font=('Times',14), command=self.save_venta)
            btnguardar.place(x=220, y= 230)
                
    def listar_venta(self):
            self.limpiar_panel(self.frame_dinamyc)
            labelform = tk.Label(self.frame_dinamyc,text="LISTADO DE VENTAS", font=('Times',16),fg="#9fa8da")
            labelform.place(x=70, y=70)
            self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("pago","total"))
            self.tablausuarios.heading("#0", text="cliente")
            self.tablausuarios.heading("pago", text="pago")
            self.tablausuarios.heading("total", text="total")
            
            with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas.json", "r", encoding='utf-8') as file:
                    ventas = json.load(file)
                    for usuarios in ventas["ventas"]:
                        self.tablausuarios.insert("", "end", text=f'{usuarios["cliente"]}',values=(f'{usuarios["pago"]}',f'{usuarios["total"]}'))
            self.tablausuarios.place(x=70, y=100)

            labelcoordenada = tk.Label(self.frame_dinamyc,text="Coordenada de la venta:", font=('Times',14))
            labelcoordenada.place(x=70,y=350)
            coordenada = tk.Entry(self.frame_dinamyc,font=('Times',14))
            coordenada.place(x= 280,y=350)

            labelcorte = tk.Label(self.frame_dinamyc,text="Reserva: ", font=('Times',14))
            labelcorte.place(x=70, y=380)

            with open(r'C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\reserva.json', 'r') as jf:
                reservaaa = json.load(jf)
            
            clies = [clien["cliente"] for clien in reservaaa["reservas"]]
            
            self.combo_cliente = ttk.Combobox(self.frame_dinamyc,
                values= clies
            )
            self.combo_cliente.place(x= 220, y=380)
            self.combo_cliente.bind("<<ComboboxSelected>>", self.cliente_selection)

            labelprecio = tk.Label(self.frame_dinamyc,text="PAGO: ", font=('Times',14))
            labelprecio.place(x=70, y=410)
            

            self.combo_pago = ttk.Combobox(self.frame_dinamyc,
                values= ["Transferencia","En la barberia"]
            )
            self.combo_pago.place(x= 220, y=410)
            self.combo_pago.bind("<<ComboboxSelected>>", self.pago_selection)


            def eliminar():

                if coordenada.get() == "":
                    
                    messagebox.showerror("","rellene los campos")
                else:

                    nuevo = ventas["ventas"]

                    coordenadaa = int(coordenada.get())
                    del nuevo[coordenadaa]

                    with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas.json", 'w') as jf: 
                            json.dump(ventas, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Reserva eliminada con exito",parent=self)

            def actualizar():

                if coordenada.get() == "":
                    
                    messagebox.showerror("","rellene los campos")
                else:

                    coordenadaa = int(coordenada.get())
                    nuevo = ventas["ventas"]

                    for cl in nuevo:

                        cliente = self.seleccion_cliente or cl["Cliente"]
                        pago = self.combo_pago.get() or cl["pago"]
                        

                    nuevo[coordenadaa] = {
                        "cliente": cliente,
                        "pago": pago
                        
                    }


                    with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas.json", 'w') as jf: 
                            json.dump(ventas, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Actualizacion exitosa",parent=self)

        
            btneliminar = tk.Button(self.frame_dinamyc, text="ELIMINAR", font=('Times',14),command= eliminar)
            btneliminar.place(x=70, y=460)

            btnactualiza = tk.Button(self.frame_dinamyc, text="ACTUALIZAR", font=('Times',14),command=actualizar)
            btnactualiza.place(x= 280, y=460)


    def save_venta(self):
                    
            if self.combo_cliente == "" or self.combo_pago == "":
                
                messagebox.showerror("","rellene los campos")
            else:
                
                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas totales.json", "r", encoding='utf-8') as file:
                        ventas = json.load(file)

                        if self.combo_pago.get() == "Transferencia":
                        
                            ventas["ventas"].append({
                                    'cliente': self.seleccion_cliente,
                                    'pago': "Transferencia",
                                    "total": co
                            
                                })
                            with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas totales.json", 'w') as jf: 
                                json.dump(ventas, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"reserva registrada con exito",parent=self)
                        
                        else:

                            with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas.json", "r", encoding='utf-8') as file:
                                ventass = json.load(file)
                        
                                ventass["ventas"].append({
                                            'cliente': self.seleccion_cliente,
                                            'pago': "En la barberia",
                                            "total": co
                                    
                                        })
                                with open(r"C:\Users\Administrator\Desktop\parcial final\LoginApp\formularios\data\ventas.json", 'w') as jf: 
                                        json.dump(ventass, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"reserva registrada con exito",parent=self)


    def limpiar_panel(self,panel):
        # Función para limpiar el contenido del panel
            for widget in panel.winfo_children():
                widget.destroy()